<?php

// 1. 建議在最上方加入錯誤回報，方便之後有其他問題可以直接看出來
ini_set('display_errors', 1);
error_reporting(E_ALL);

$mysqli = new mysqli(
    "sql109.infinityfree.com",
    "if0_42237574",
    "s3210vivian", // <-- 請注意：這裡通常不是你登入 InfinityFree 網站面板的密碼！
    "if0_42237574_db"
);

// 2. 修正拼字錯誤：connaect_error 改為 connect_error
if ($mysqli->connect_error) {
    die('連接失敗: ' . $mysqli->connect_error);
}

$mysqli->set_charset('utf8mb4');

define('BASE_URL', 'https://pilates.great-site.net/pilates_studio/');
define('UPLOAD_PATH', $_SERVER['DOCUMENT_ROOT'] . '/uploads/');

session_start();

date_default_timezone_set('Asia/Taipei');

?>